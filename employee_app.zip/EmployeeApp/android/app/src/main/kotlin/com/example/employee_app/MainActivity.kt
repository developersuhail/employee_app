package com.example.employee_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
